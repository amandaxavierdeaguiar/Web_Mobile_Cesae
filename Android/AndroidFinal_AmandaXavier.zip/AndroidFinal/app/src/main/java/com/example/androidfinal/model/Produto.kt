package com.example.androidfinal.model

/*class Produto(var id:Int, var modelo:String, var preco: Double) {
}*/

class Produto(var modelo:String, var preco: Double) {
}