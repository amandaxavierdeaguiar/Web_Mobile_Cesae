<?php $__env->startSection('content'); ?>
    <ul>
        <?php $__currentLoopData = $weekDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($day); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h6>Dados do curso: </h6>
    <p>Nome: <?php echo e($info['nome']); ?></p>
    <p>Horas: <?php echo e($info['hours']); ?>h</p>

    <h6>Cesae info: </h6>
    <p>Nome: <?php echo e($cesae['name']); ?></p>
    <p>Endereço: <?php echo e($cesae['address']); ?></p>
    <p>E-mail: <?php echo e($cesae['email']); ?>h</p>


    <ul>
        <li><?php echo e($myFirstVar); ?></li>
        <li><?php echo e($weekDays[0]); ?></li>
        <li><a href="<?php echo e(route('welcome')); ?>">Welcome!</li>
        <li><a href="<?php echo e(route('users.all')); ?>">Todos os Utilizadores!</li>
        <li><a href="<?php echo e(route('users.new')); ?>">Insira novos Utilizadores</li>
        <li><a href="<?php echo e(route('tasks.all')); ?>">Todas as tarefas</li>
    </ul>
    <img src="<?php echo e(asset('images/Odie.png')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amand\Documents\MeusProjetos\Web_Mobile_Cesae\ServerSide\Laravel\WebServerSideNew\resources\views/utils/home.blade.php ENDPATH**/ ?>