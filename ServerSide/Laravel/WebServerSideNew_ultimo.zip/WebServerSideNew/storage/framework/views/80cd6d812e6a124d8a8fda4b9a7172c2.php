<?php $__env->startSection('content'); ?>
<h1>Aqui tens todas as tarefas</h1>

<table class="table">
    <thead>
      <tr>
        <th scope="col">id</th>
        <th scope="col">Nome</th>
        <th scope="col">Estado</th>
        <th scope="col">Data de Conclusão</th>
        <th scope="col">User</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($task->id); ?></th>
                <td><?php echo e($task->name); ?></td>
                <td><?php echo e($task->status); ?></td>
                <td><?php echo e($task->due_at); ?></td>
                <td><?php echo e($task->username); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amand\Documents\MeusProjetos\Web_Mobile_Cesae\ServerSide\Laravel\WebServerSideNew\resources\views/tasks/all_tasks.blade.php ENDPATH**/ ?>