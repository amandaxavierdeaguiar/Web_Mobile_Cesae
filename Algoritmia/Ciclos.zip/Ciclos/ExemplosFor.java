
class ExemplosFor
{
    ExemplosFor()
    {
        // ciclo For - exemplo simples
        // Primeira parte - Declaração e inicialização da variável
        // Segunda parte - condição do ciclo (pergunta) - resultado booleano
        // Terceira parte - Incremento ou decremento da variável do ciclo.
        
        for (int i=0; i<13 ; i++)
        {
            System.out.println(i);
        }    
        
        for (int i=2; i<8 ; i+=2)
        {
            System.out.println(i);
        }        
    }
}
